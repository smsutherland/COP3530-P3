#ifndef _AVL_H
#define _AVL_H

#include "tree.hpp"
#include <algorithm>

template <typename T>
class avlBase: public Tree<T> {
private:

	//node of tree
	struct node {

		//key
		T key;

		//height of node
		int height;

		//left, right and parent
		node *left;
		node *right;
		node* parent;

		//constructor
		node(T k): key(k), height(1), left(nullptr),
			right(nullptr), parent(nullptr) {}
	};

	//a pointer to head
	node* root;

	// clear tree
	void clear(node* node) {
		if (node != NULL)
		{
			//clear left sub tree
			clear(node->left);
			//clear right sub tree
			clear(node->right);
			//delete current node
			delete node;
		}
	}

	//height of node
	int height(node* node) {
		if (node == NULL)
		{
			return -1;
		}
		//left height
		int leftHeight = height(node->left);
		//right height
		int rightHeight = height(node->right);

		//get max height and add by one
		if (leftHeight > rightHeight)
		{
			return leftHeight + 1;
		}
		else {
			return rightHeight + 1;
		}
	}

	//get balance
	int balance(node* node) {
		//subtract 2 heights of sub left and sub right tree		
		return height(node->right) - height(node->left);
	}

	//find and remove
	void findRemove(const T& t, node* currentNode) {
		if (currentNode == NULL) {
			return;
		}
		else {
			if (currentNode->key > t)
			{//remove left sub tree
				findRemove(t, currentNode->left);
			}
			else if (currentNode->key < t)
			{//remove right sub tree
				findRemove(t, currentNode->right);
			}
			else if (currentNode->key == t)
			{//remove this node
				removeNode(currentNode);
			}
		}
	}

	//remove node
	void removeNode(node* currentNode) {
		node* rightNode;
		// remove child node
		if (currentNode->left == NULL || currentNode->right == NULL) {
			// the root is deleted
			if (currentNode->parent == NULL) {
				this->root = NULL;
				delete (currentNode);
				currentNode = NULL;
				return;
			}
			rightNode = currentNode;
		}
		else {
			// currentNode has 2 children
			rightNode = rightMostLeftParent(currentNode);
			currentNode->key = rightNode->key;
		}

		//find parent node
		node* parentNode;
		if (rightNode->left != NULL) {
			parentNode = rightNode->left;
		}
		else {
			parentNode = rightNode->right;
		}

		if (parentNode != NULL) {
			parentNode->parent = rightNode->parent;
		}

		if (rightNode->parent == NULL) {
			//if parent if right is null, set parent to root node
			this->root = parentNode;
		}
		else {
			//if left of parent of right is right
			if (rightNode == rightNode->parent->left) {
				//set parent to left of parent of right
				rightNode->parent->left = parentNode;
			}
			else {
				//set parent to right of parent of right node
				rightNode->parent->right = parentNode;
			}
			//balance tree
			recursiveBalance(rightNode->parent);
		}

		delete (rightNode);
		rightNode = NULL;
	}

	//balance tree
	void recursiveBalance(node* currentNode) {

		int bal = balance(currentNode);

		// rotate if balance is -2 or 2
		if (bal == -2) {
			//rotate right
			if (height(currentNode->left->left) >= height(currentNode->left->right)) {
				currentNode = rotateRight(currentNode);
			}
			else {
				//rotate left than right
				currentNode = doubleRotateLeftRight(currentNode);
			}
		}
		else if (bal == 2) {
			//rorate left
			if (height(currentNode->right->right) >= height(currentNode->right->left)) {
				currentNode = rotateLeft(currentNode);
			}
			else {
				//rotate right then left
				currentNode = doubleRotateRightLeft(currentNode);
			}
		}

		if (currentNode->parent != NULL) {
			recursiveBalance(currentNode->parent);
		}
		else {
			root = currentNode;
		}
	}

	//right most left or parent of a node
	node* rightMostLeftParent(node* currentNode) {
		if (currentNode->left != NULL) {
			node* leftNode = currentNode->left;
			return rightMost(leftNode);
		}
		else {
			return (parentLeftMost(currentNode));
		}
	}

	//right most node
	node* rightMost(node* currentNode) {
		if (currentNode->right != NULL)
		{
			return rightMost(currentNode->right);
		}
		return currentNode;
	}

	//most left node of parent
	node* parentLeftMost(node* currentNode) {
		node* parentNode = currentNode->parent;
		if (parentNode != NULL && currentNode == parentNode->left)
		{
			return parentLeftMost(parentNode);
		}
		return parentNode;
	}

	//left rotation node
	node* rotateLeft(node* currentNode) {
		//left node
		node* leftNode = currentNode->right;

		//set parent of current to parent of left
		leftNode->parent = currentNode->parent;

		//set left  of left node to right of current
		currentNode->right = leftNode->left;

		if (currentNode->right != NULL) {
			//set current to parent of right of current
			currentNode->right->parent = currentNode;
		}

		//set current to left of left node
		leftNode->left = currentNode;
		//set left node to parent of current
		currentNode->parent = leftNode;

		if (leftNode->parent != NULL) {
			//if right of parent of left is current
			if (leftNode->parent->right == currentNode) {
				//set left to right of parent of left
				leftNode->parent->right = leftNode;
			}
			else if (leftNode->parent->left == currentNode) {
				//set left to left of parent of left node
				leftNode->parent->left = leftNode;
			}
		}

		return leftNode;
	}

	//right rotation node
	node* rotateRight(node* currentNode) {
		//left node
		node* leftNode = currentNode->left;
		//parent node
		leftNode->parent = currentNode->parent;

		//set right of left to left of current
		currentNode->left = leftNode->right;

		if (currentNode->left != NULL) {
			//set current to parent of left of current
			currentNode->left->parent = currentNode;
		}

		//set current to right of left
		leftNode->right = currentNode;
		//set left to parent of current
		currentNode->parent = leftNode;

		if (leftNode->parent != NULL) {
			//if right of parent of left is current node
			if (leftNode->parent->right == currentNode) {
				//set left to right of parent of left
				leftNode->parent->right = leftNode;
			}
			else if (leftNode->parent->left == currentNode) {
				//set left to left of parent of left
				leftNode->parent->left = leftNode;
			}
		}

		return leftNode;
	}

	//rotate left then right
	node* doubleRotateLeftRight(node* currentNode) {
		currentNode->left = rotateLeft(currentNode->left);
		return rotateRight(currentNode);
	}

	//rotate right then left
	node* doubleRotateRightLeft(node* currentNode) {
		currentNode->right = rotateRight(currentNode->right);
		return rotateLeft(currentNode);
	}

	//insert helper method
	void insertHelper(node* rootNode, node* newNode) {
		// insert as root if root node is NULL
		if (rootNode == NULL) {
			root = newNode;
		}
		else {
			// try with the left sub tree
			if (newNode->key < rootNode->key) {
				if (rootNode->left == NULL) {
					rootNode->left = newNode;
					newNode->parent = rootNode;
					// balance the tree
					recursiveBalance(rootNode);
				}
				else { //call recursive to insert left
					insertHelper(rootNode->left, newNode);
				}
			}
			else if (newNode->key > rootNode->key)
			{// try with the right sub tree
				if (rootNode->right == NULL) {
					rootNode->right = newNode;
					newNode->parent = rootNode;

					// balance the tree
					recursiveBalance(rootNode);
				}
				else {//call recursive to insert right
					insertHelper(rootNode->right, newNode);
				}
			}
			else {
				//duplicate
			}
		}
	}

	//search in range (count)
	int searchUtil(node *current, const T& from, const T& to) const
	{
		if (!current) //empty current root
			return 0;

		T k = current->key;

		if (k >= from && k <= to)//fall in range
		{
			return 1 + searchUtil(current->left, from, to) +
				searchUtil(current->right, from, to);
		}
		else if (k < from) //left outside of range [from:to]
		{
			return searchUtil(current->right, from, to);
		}
		else //right outside of range [from:to]
		{
			return searchUtil(current->left, from, to);
		}
	}

public:
	//constructor
	avlBase() {
		root = NULL;
	}

	//destructor
	~avlBase() {
		clear(root);
	}

	//insert a node into the avlBase
	void insert(const T& x) {

		//create new node
		node* newNode = new node(x);
		newNode->left = NULL;
		newNode->right = NULL;
		newNode->parent = NULL;

		insertHelper(root, newNode);
	}

	//remove a node 
	void remove(const T& t) { 
		findRemove(t, root);
	}

	//search in range (count)
	int search(const T& from, const T& to) const{
		return searchUtil(root, from, to);
	}
};

#endif
